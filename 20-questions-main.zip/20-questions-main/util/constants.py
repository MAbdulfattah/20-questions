POSSIBLE_ANSWERS = ['yes', 'no']
QUESTIONS_LIMIT = 250 
EMPTY_KG = 'You seem to have outsmarted me, what where you thinking about? '
URL = 'http://127.0.0.1:7200/repositories/top2021'